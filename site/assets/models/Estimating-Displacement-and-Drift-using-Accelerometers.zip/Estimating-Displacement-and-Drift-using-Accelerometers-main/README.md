# Estimating-Displacement-and-Drift-In-Structures-using-Accelerometers
This repository includes the data, python scripts, and files used as part of Appendix F of my Thesis titled "Quantifying the influence of reducing design drift limits".
