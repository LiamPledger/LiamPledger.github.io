# Rectilinear-confinement-of-RC-members
This repository includes data from different tests series of concrete columns subjected to monotonic axial load until failure
